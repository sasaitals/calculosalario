/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author autologon
 */
public class Calcular {
    private Double sBruto;
    private Double inss;
    private Double fgts;
    private Double ir;
    private Double sLiquido;

    public Calcular() {
    }

    public Calcular(Double sBruto) {
        this.sBruto = sBruto;
    }

    public Double getsBruto() {
        return sBruto;
    }

    public void setsBruto(Double sBruto) {
        this.sBruto = sBruto;
    }

    public Double getInss() {
        return inss;
    }

    public void setInss(Double inss) {
        this.inss = inss;
    }

    public Double getFgts() {
        return fgts;
    }

    public void setFgts(Double fgts) {
        this.fgts = fgts;
    }

    public Double getIr() {
        return ir;
    }

    public void setIr(Double ir) {
        this.ir = ir;
    }

    public Double getsLiquido() {
        return sLiquido;
    }

    public void setsLiquido(Double sLiquido) {
        this.sLiquido = sLiquido;
    }
    
    public Double calculaFgts(){
        this.sBruto = this.sBruto * (8/100);
        return sBruto;
    }
    
    public Double calculaInss(){
        if(this.sBruto <= 1045.00){
            this.inss = this.sBruto - (this.sBruto * (7.50/100));
        } else if(this.sBruto <= 2089.60){
            this.inss = this.sBruto - (this.sBruto * (9/100));
        } else if(this.sBruto <= 3134.40){
            this.inss = this.sBruto - (this.sBruto * (12/100));
        }else if(this.sBruto <= 6101.06){
            this.inss = this.sBruto - (this.sBruto * (14/100));
        }else {
            this.inss = 854.15;
        }
        return this.inss;
        
    }
    
    public Double calculaIr(){
        if(this.sBruto <= 1903.98){
            this.ir = 00.0;
            return this.ir;
        } else if(this.sBruto <= 2826.65){
            this.ir = this.sBruto * (7.5/100);
            return this.ir;
        } else if(this.sBruto <= 3751.05){
            this.ir = this.sBruto * (15/100);
            return this.ir;
        }else if(this.sBruto <= 4664.68){
            this.ir = this.sBruto * (22.5/100);
            return this.ir;
        }else if(this.sBruto > 4664.68){
            this.ir = this.sBruto * (27.5/100);
            return this.ir;
        }
        return this.ir;
    }
    
    public Double calculaSalarioLiquido(){
        this.sLiquido = this.sBruto - (this.ir + this.inss);
        return this.sLiquido;
    }
}
